#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
#include<stdio.h>

int main(){
	struct{
		int ticket_no;
	}db,db1;
	struct flock lock;
	int fd;
	fd=open("db",O_RDWR);
//	read(fd,&db,sizeof(db));
	lock.l_type=F_WRLCK;
	lock.l_whence=SEEK_SET;
	lock.l_start=0;
	lock.l_len=0;
	lock.l_pid=getpid();
	printf("Before entering into critical section\n");
	fcntl(fd,F_SETLKW,&lock);
	read(fd,&db,sizeof(db));

	printf("Ticket number:%d",db.ticket_no);
	db.ticket_no++;
	printf("Ticket number:%d",db.ticket_no);
	lseek(fd,0L,SEEK_SET);
//	read(fd,&db1,sizeof(db1));
//	printf("no from db1%d",db1.ticket_no);
	printf("Inside cs\n");
	printf("enter to unlock\n");
	write(fd,&db,sizeof(db));
	lseek(fd,0L,SEEK_SET);
	read(fd,&db1,sizeof(db1));
      	printf("no from db1%d",db1.ticket_no);

	getchar();
	lock.l_type=F_UNLCK;
	printf("unlocked\n");
	fcntl(fd,F_SETLK,&lock);
	printf("finish\n");
}
