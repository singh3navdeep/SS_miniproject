#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
int main(void)
{
	int fd;
	struct data{
		int ticket_no;
	}db,db1;
	struct data d[2];
	d[0].ticket_no=10;
	d[1].ticket_no=20;
	fd=open("database",O_CREAT|O_RDWR|O_APPEND,0744);
	write(fd,&d[0],sizeof(db));
	write(fd,&d[1],sizeof(db1));
	close(fd);
	printf("%ld",sizeof(db));
	fd=open("database",O_RDONLY);
	lseek(fd,4,SEEK_SET);
	read(fd,d,sizeof(d));
	printf("ticket no %d",d[1].ticket_no);
	close(fd);
}
