#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
int record_lock(int fd,char type, char whence, int start, int length)
{
        struct flock fl;
        fl.l_type = type;               /* F_RDLCK, F_WRLCK, F_UNLCK */
        fl.l_whence = whence;   /* byte offset, relative to l_whence */
        fl.l_start=start;               /* SEEK_SET, SEEK_CUR, SEEK_END */
        fl.l_len=length;                /* #bytes (0 means to EOF) */

        return (fcntl(fd,F_SETLKW,&fl));
}

int main(int argc,char const *argv[])
{
	int fd,i=0;
	struct data{
		int ticket_no;
	}db,db1;
	struct data d;
	db.ticket_no=10;
	db1.ticket_no=20;
	fd=open("database",O_CREAT|O_RDWR|O_APPEND,0744);
	write(fd,&db,sizeof(db));
	write(fd,&db1,sizeof(db1));
	//printf("%ld",sizeof(fd));
	if(record_lock(fd,F_WRLCK,atoi(argv[1]),atoi(argv[2]),atoi(argv[3])) == -1){
                printf("Error in getting lock \n");
                return 0;
        }
	printf("Press enter to unlock \n");
	getchar();
	close(fd);
        record_lock(fd,F_UNLCK,atoi(argv[1]),SEEK_CUR,atoi(argv[2]));
        printf("\nUnlocked   \n");

//	printf("%ld",sizeof(d));
//	fd=open("database",O_RDONLY);
	//lseek(fd,4,SEEK_SET);
	
//	while(read(fd,&d,sizeof(db))>0)
//		printf("ticket no %d\n",d.ticket_no);
	close(fd);
}
