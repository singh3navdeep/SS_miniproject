#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<stdlib.h>
#include <arpa/inet.h>
#include<unistd.h>
int main(int argc, char *argv[])
{
int first[5],server_reply[6],i,choice;
int sockfd, portno, n;
char a[180],b[210],pwd[8],m[180];
int acc;
struct sockaddr_in serv_addr;
if (argc < 3)
{
fprintf(stderr,"usage %s hostname port\n", argv[0]);
exit(0);
}

portno = atoi(argv[2]);
sockfd = socket(AF_INET, SOCK_STREAM, 0);

inet_aton(argv[1], &(serv_addr.sin_addr));

serv_addr.sin_family=AF_INET;

serv_addr.sin_port = htons(portno);
if(connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
{
        printf("Error in connected\n");
}
printf("connectedtoserver\n");
read(sockfd,a,sizeof(a));
printf("%s",a);
scanf("%d",&acc);
write(sockfd,&acc,sizeof(acc));
read(sockfd,b,sizeof(b));
printf("%s",b);
scanf("%s",pwd);
write(sockfd,pwd,sizeof(pwd));
read(sockfd,m,sizeof(m));
printf("%s\n",m);
scanf("%d",&choice);
write(sockfd,&choice,sizeof(choice));
}
