#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<stdlib.h>
#include <arpa/inet.h>
void bubbleSort1(int arr[], int n)
{
   int i, j,t;
   for (i = 0; i < n; i++)      
 	for (j = 0; j < n-i-1; j++) 
           if (arr[j] > arr[j+1])
              {	t=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=t;
	      }
}
int average(int arr[],int n)
{	int i,sum=0;
	for(i=0;i<n;++i)
		sum+=arr[i];
	return sum/5;
}

int main(int argc, char *argv[])
{
int value[6],i,avg;
int sockfd, newsockfd, portno;
socklen_t clilen;
struct sockaddr_in serv_addr, cli_addr;
int n;

if (argc < 2)
{
fprintf(stderr,"ERROR, no port provided\n");
exit(1);
}

sockfd = socket(AF_INET, SOCK_STREAM, 0);

if (sockfd < 0)
{
printf("ERROR opening socket");
exit(1);
}


portno = atoi(argv[1]);

serv_addr.sin_family = AF_INET;
serv_addr.sin_addr.s_addr = inet_addr("172.16.131.67");
serv_addr.sin_port = htons(portno);
if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
{
printf("ERROR on binding\n");
exit(1);
}

printf("Waiting for Client\n");

listen(sockfd,5);

clilen = sizeof(cli_addr);

while(1)
{
	newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);
	if (newsockfd < 0)
	{
		printf("ERROR on accept");
	}
	printf("connected\n");
	//sleep(12);
	while ((n = read(newsockfd, &value, 5 * sizeof(int))) > 0) {
 		bubbleSort1(value, 5);
        	avg=average(value,5);
		value[5]=avg; 
        	write(newsockfd, &value, 6 * sizeof(int));
    	}

printf("Client disconnected\n");



	if (n < 0)
	{
		printf("ERROR writing to socket");
	}
}
close(sockfd);
return 0;
}



