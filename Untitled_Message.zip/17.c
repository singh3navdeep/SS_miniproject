#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(void){
        int fd;
        fd=open("inputfile",O_WRONLY|O_APPEND);
        //char ch='y';
        int c=1;
        while(c){
		write(1,"enter ticket number",strlen("enter ticket number"));
                char val[100];
                scanf("%s",val);
                write(fd, val, strlen(val));
                write(fd,"\n",strlen("\n"));
                printf("Enter your choice\n");
                scanf("%d",&c);
        }
}

