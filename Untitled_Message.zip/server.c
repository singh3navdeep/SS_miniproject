#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<stdlib.h>
#include <arpa/inet.h>
#include<string.h>
#include <sys/stat.h>
#include <fcntl.h>
struct bank{
	char type;
	char name1[20],name2[20];
	int acc,balance,flag;
	char pwd[8];
	};
int nextaccount=206001;
void user(int newsockfd,int fd){
	printf("user");
}
void admin(int newsockfd,int fd){
	printf("\nInsideAdmin\n");
	int choice;
	struct bank b;
	char type;
	char name1[20],name2[20];
	char pass[8];
	lseek(fd,0,0);
	read(fd,&b,sizeof(b));
	printf("value of flag%d%d\n",b.flag,b.acc);
	b.flag=0;
	lseek(fd,0,0);
	if(write(fd,&b,sizeof(b))>0){
		fdatasync(fd);
		printf("\nchecking\n");
	}
	lseek(fd,0,0);
        if(read(fd,&b,sizeof(b))>0){
        	printf("\nafterlseek......%d%s\n",b.flag,b.name1);
	}

	do{
		write(newsockfd,"1-Add User\n2-Logout\nEnter Your choice::",sizeof("1-Add User\n2-Logout\nEnter Your choice::"));
		read(newsockfd,&choice,sizeof(&choice));
		if(choice==1){
			lseek(fd,0,SEEK_END);
			write(newsockfd,"Enter Type of account::(NorJ)",sizeof("Enter Type of account::(NorJ)"));
			read(newsockfd,&type,sizeof(type));
			if(type=='N'){
				write(newsockfd,"Enter Your Name::",sizeof("Enter Your Name::"));
				read(newsockfd,name1,sizeof(name1));
				b.flag=1;
				strcpy(b.name1,name1);
				strcpy(b.name2,NULL);
			}
			else if(type=='J'){
				write(newsockfd,"Enter Your Name1::\n",sizeof("Enter Your Name1::\n"));
                                read(newsockfd,name1,sizeof(name1));
				write(newsockfd,"Enter Your Name2::\n",sizeof("Enter Your Name2::\n"));
                                read(newsockfd,name1,sizeof(name2));
				b.flag=2;
				strcpy(b.name1,name1);
	                        strcpy(b.name2,name2);

				}
			write(newsockfd,"Enter your password::\n",sizeof("Enter your password::\n"));
			read(newsockfd,pass,sizeof(pass));
			strcpy(b.type,type);
			b.acc=nextaccount++;
			strcpy(b.pwd,pass);
			b.balance=0;
			write(fd,&b,sizeof(b));
			}
		else{	
			b.flag=1;
			write(lseek(fd,0,SEEK_SET),&b,sizeof(b));
			exit(0);
		}
	}while(1);

}
void login(int newsockfd){
		printf("akshat\n");
		struct bank b;
                char passwd[8];
		int u_id;
		int fd;
                fd=open("database",O_RDWR);
                write(newsockfd,"Enter Your UserId::\0",sizeof("Enter Your UserId::\0"));
                read(newsockfd,&u_id,sizeof(u_id));
		write(newsockfd,"Enter Your Password::\0",sizeof("Enter Your Password::\0"));
		read(newsockfd,passwd,sizeof(passwd));
		printf("%d",u_id);
                while(read(fd,&b,sizeof(b))>0){
			if(b.acc==u_id){
			
				if(b.flag>0)
				{
					if(b.type=='A')
					{
						admin(newsockfd,fd);
					}
					else{
						user(newsockfd,lseek(fd,-1*sizeof(b),SEEK_CUR));
					}

				}
				else{
					write(newsockfd,"Already Login,Please Try later::\0",sizeof("Already Login,Please Try later::\0"));
				}
			}

		}
		write(newsockfd,"Wrong UserName And Password\0",sizeof("Wrong UserName And Password\0"));
}



int main(int argc,char *argv[]){
int sockfd, newsockfd, portno;
socklen_t clilen;
struct sockaddr_in serv_addr, cli_addr;
int n;

if (argc < 2)
{
fprintf(stderr,"ERROR, no port provided\n");
exit(1);
}

sockfd = socket(AF_INET, SOCK_STREAM, 0);

if (sockfd < 0)
{
printf("ERROR opening socket");
exit(1);
}


portno = atoi(argv[1]);

serv_addr.sin_family = AF_INET;
serv_addr.sin_addr.s_addr = INADDR_ANY;
serv_addr.sin_port = htons(portno);
if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
{
	printf("ERROR on binding\n");
	exit(1);
}

printf("Waiting for Client\n");

listen(sockfd,5);
printf("after listen\n");
clilen = sizeof(cli_addr);

while(1)
{
        newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);
	printf("after accept\n");
        if (newsockfd < 0)
        {
                printf("ERROR on accept");
        }
	if(!fork()){
			printf("going to login\n");
			login(newsockfd);
		}
}
}



