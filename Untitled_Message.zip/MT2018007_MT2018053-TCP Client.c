#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<stdlib.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
int first[5],server_reply[6],i;
int sockfd, portno, n;
struct sockaddr_in serv_addr;
printf("Enter the number to be sorted\n");
    for(i=0;i<5;++i)
        scanf("%d",&first[i]);
if (argc < 3)
{
fprintf(stderr,"usage %s hostname port\n", argv[0]);
exit(0);
}

portno = atoi(argv[2]);
sockfd = socket(AF_INET, SOCK_STREAM, 0);

inet_aton(argv[1], &(serv_addr.sin_addr));

serv_addr.sin_family=AF_INET;

serv_addr.sin_port = htons(portno);
if(connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
{
	printf("Error in connected\n");
}
printf("connected\n");
if (write(sockfd, &first, 5 * sizeof(int), 0) < 0) {
        printf("Send failed\n");
        return 1;
    }
if (read(sockfd, &server_reply, 6 * sizeof(int), 0) < 0) {
        printf("recv failed\n");
        return 0;
    }
 
    puts("\nServer reply :");
    for (i = 0; i < 5; i++) {
        printf("%d ", server_reply[i]);
    }
    printf("\nThe average of numbers = %d\n",server_reply[5]);
return 0;
}
